
 jQuery(document).ready(function(){
    jQuery(document).on("click","#fSubmit",function(){
        event.stopImmediatePropagation();
        event.preventDefault();
        debugger;
        var obj = {
            name: jQuery("#name").val(),
            email: jQuery("#exampleInputEmail1").val(),
            mobile: jQuery("#Mobile").val(),
            message: jQuery("#exampleFormControlTextarea5").val()
        }
        localStorage.setItem("PersonDetails", JSON.stringify(obj)); // Save the obj as string
        var item = JSON.parse(localStorage.getItem("PersonDetails"));
        alert(item.name+" details has been saved Sucessfully!");
        jQuery("#name").val("");
        jQuery("#exampleInputEmail1,#Mobile,#exampleFormControlTextarea5").val("");
        jQuery("#capta").prop("checked","");
    });
    jQuery(".acc-body").slideUp();
    jQuery(".acc-card-header").on("click",function(){
        var elems = jQuery(".acc-card-header");
        var _self = jQuery(this);
        _self.find(".d-arrow").toggleClass("rotate");
        _self.siblings(".acc-body").slideToggle();
    });
});

// corousal_script
$(document).ready(function () {
    jQuery(".return-top").on("click",function(){
        window.scrollTo({ top: 0, behavior: 'smooth' });
    })
var div_width = $('.testimonial-item').width();
var div_len = $('.testimonial-item').length + 8;
// console.log(div_len)
var full_width = div_width * div_len;
// console.log(full_width);

jQuery.fn.multi_click = function (on_single_click, on_double_click, timeout) {
    return this.each(function () {
        var clicks = 0,
            self = this;
        on_double_click = on_double_click || on_single_click
        jQuery(this).click(function (event) {
            clicks++;
            if (clicks == 1) {
                setTimeout(function () {
                    if (clicks == 1) {
                        on_single_click.call(self, event);
                    } else {
                        on_double_click.call(self, event);
                    }
                    clicks = 0;
                }, timeout || 500);
            }
        });
    });
}

$('.testimonial-items').width(full_width);


function right_arrow() {

    var left_prop = parseInt($('.testimonial-items').css('left'));
    var left = 500;
    if(window.innerWidth < 580){
        left = jQuery(".testimonial-item").outerWidth();
    }
    var full_prop = left_prop - left;
    $('.arrow-left').removeClass('pointer');



    $('.testimonial-item.active').removeClass('active').next('.testimonial-item').addClass('active');
    $('.testimonial-items').css('left', full_prop);

    // condition

    var cor_index = $('.testimonial-items .testimonial-item.active').index();
    var cor_last = $('.testimonial-items .testimonial-item').last().index();


    if (cor_index >= cor_last) {
        $('.arrow-right').addClass('pointer');

    }


}


function left_arrow() {

    var left_prop = parseInt($('.testimonial-items').css('left'));
    var left = 500;
    if(window.innerWidth < 580){
        left = jQuery(".testimonial-item").outerWidth();
    }       
    var full_prop = left_prop + left;
    $('.arrow-right').removeClass('pointer');
    $('.testimonial-items').css('left', full_prop);
    $('.testimonial-item.active').removeClass('active').prev('.testimonial-item').addClass('active');

    // condition

    var cor_index = $('.testimonial-items .testimonial-item.active').index();
    var cor_last = $('.testimonial-items .testimonial-item').first().index();



    if(cor_index == cor_last) {
        $('.arrow-left').addClass('pointer');

    }

}
// $('.arrow-left').on('click', left_arrow);



var cor_index = $('.testimonial-items .testimonial-item.active').first().index();
// console.log(cor_index);
if(cor_index == 0) {
    $('.arrow-left').addClass('pointer');
}

$(function () {
    $(".arrow-right")
        .multi_click(function () {
            right_arrow();
        });
});


$(function () {
    $(".arrow-left")
        .multi_click(function () {
            left_arrow();
        })
});
});